cp /storage/emulated/0/Download/libs /data/data/com.termux/files/home/GWC/libs
